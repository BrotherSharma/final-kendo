using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;

namespace Test.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        public readonly NpgsqlConnection _conn;
        public StudentRepository(NpgsqlConnection conn)
        {
            _conn=conn;
        }
        public List<tbladmin> GetAll()
         {
            List<tbladmin> result = new List<tbladmin>();
            _conn.Open();
            using NpgsqlCommand command =  new NpgsqlCommand("SELECT c_id,c_category,c_bookname,c_date FROM t_admin",_conn);
           using(var dr = command.ExecuteReader())
            {
                while(dr.Read())
                {
                    var data = new tbladmin()
                    {
                        c_id = Convert.ToInt32(dr["c_id"]),
                        c_category = dr["c_category"].ToString(),
                        c_bookname = dr["c_bookname"].ToString(),
                        c_date = dr.GetFieldValue<DateTime>("c_date"),
                       
                    };
                    result.Add(data);
                }
            }
            _conn.Close();
            return result;
         }


         public List<tblcategory> GetAllCategory()
        {
            var product = new List<tblcategory>();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_category ",_conn);
            command.CommandType = CommandType.Text;
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
                var tblcategory = new tblcategory();
                {
                    tblcategory.c_id=Convert.ToInt32(reader["c_id"]);
                    tblcategory.c_category= reader["c_category"].ToString();
                   
                }
                product.Add(tblcategory);
            }
            _conn.Close();
            return product;
        }

         public tbladmin GetOne(int id)
        {
            var user = new tbladmin();
            _conn.Open();
            var command = new NpgsqlCommand("SELECT c_id, c_category, c_bookname, c_date FROM t_admin WHERE c_id = @id;",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id",id);
            var reader = command.ExecuteReader();
            while(reader.Read())
            {
                    user.c_id = Convert.ToInt32(reader["c_id"]);
                    user.c_category = reader["c_category"].ToString();
                    user.c_bookname = reader["c_bookname"].ToString();
                    user.c_date = reader.GetFieldValue<DateTime>("c_date");
            }
            _conn.Close();
            return user;
        }
        public void Insert(tblhistory tblhistory)
         {
            try
            {
                _conn.Open();
            using var command = new NpgsqlCommand("INSERT INTO t_history(c_category,c_bookname,c_date,c_status) VALUES (@c_category,@c_bookname,@c_date,'Requested')",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_category",tblhistory.c_category);
            command.Parameters.AddWithValue("@c_bookname",tblhistory.c_bookname);
            command.Parameters.AddWithValue("@c_date",tblhistory.c_date);
            command.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally{
                _conn.Close();
            }
           
         }

        


    }
}