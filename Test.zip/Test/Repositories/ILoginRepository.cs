using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;

namespace Test.Repositories
{
    public interface ILoginRepository
    {
        public bool Login(tbllogin login);
    }
}