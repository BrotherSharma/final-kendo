using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;

namespace Test.Repositories
{
    public interface IAdminRepository
    {
        public List<tblcategory> GetAllCategory();
        public List<tbladmin> GetAll();
        public void Insert(tbladmin tbladmin);
         public void Update(tbladmin tbladmin);
         public void Delete(int id);
         public List<tblstudent> GetAllStudent();
        public List<tblfeild> GetAllFeild();
        public void AddStudent(tblstudent tblstudent);
        public List<tblhistory> GetHistory();
    }
}