using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Npgsql;

namespace Test.Repositories
{
    public interface IStudentRepository
    {
        public List<tbladmin> GetAll();
        public List<tblcategory> GetAllCategory();
        public tbladmin GetOne(int id);
        public void Insert(tblhistory tblhistory);

    }
}