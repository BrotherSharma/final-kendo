using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Test.Models;
using Test.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Test.Controllers
{
    //[Route("[controller]")]
    public class StudentController : Controller
    {
        private readonly ILogger<StudentController> _logger;
        private readonly IStudentRepository _repo;

        public StudentController(ILogger<StudentController> logger, IStudentRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public IActionResult Index()
        {
            return View();
        }
         public IActionResult History()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            var result = _repo.GetAll();
            return Json(result);
        }
        
        [HttpGet]
        public IActionResult GetDep()
        {
            var data =_repo.GetAllCategory();
            return Json(data);
        }
        public IActionResult GetOne(int id)
        {
            var GetProduct = _repo.GetOne(id);
            return Json(GetProduct);
        }

        [HttpPost]
        public IActionResult Add(tblhistory model)
        {
      
            _repo.Insert(model);
            return Json(new { success = true});  
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}