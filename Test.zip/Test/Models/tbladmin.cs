using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Models
{
    public class tbladmin
    {
         public int c_id{get; set;}
        public string c_category{get; set;}
        public string c_bookname{get; set;}
        public int c_initialstock{get; set;}
        public int c_availablestock{get; set;}
        public DateTime c_date{get; set;}
        
    }
}